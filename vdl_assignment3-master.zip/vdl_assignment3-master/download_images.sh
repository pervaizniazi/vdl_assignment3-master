#!/usr/bin/env sh
wget http://places.csail.mit.edu/unit_annotation/data/images.tar
tar -xvf images.tar

