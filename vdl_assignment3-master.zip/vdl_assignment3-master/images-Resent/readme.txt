Here we randomly select 1/4 number of total images from ImageNet test set and SUN database. So there are 25,000 images from ImageNet (object centric dataset) and 27,189 images from SUN (scene centric dataset).

