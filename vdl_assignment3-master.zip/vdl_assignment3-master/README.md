# Assignment 3 
Assignment 3 for VDL lecture

Please raise issue here itself if you face any problems with the code. You can e-mail for remote access and environment related issues.
